package org.example.CS320ProjectOne;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class TaskTest {

    //Testing the Task class and constructor using assertTrue
    @Test
    void testTaskClass() {
        Task task = new Task("123", "Test", "Testing the class");

        assertTrue(task.getId().equals("123"));
        assertTrue(task.getName().equals("Test"));
        assertTrue(task.getDesc().equals("Testing the class"));
    }

    /*
     * Nested tests for length validation
     */

    @Nested
    class testLength {

        @Test
        void testIdTooLong() {
            assertThrows(IllegalArgumentException.class, () -> {
                new Task("6546446556456646566", "TestName", "Under fifty chars");
            });
        }

        @Test
        void testNameTooLong() {
            assertThrows(IllegalArgumentException.class, () -> {
                new Task("123", "TestNameLongerThan20Char", "Under fifty chars");
            });
        }

        @Test
        void testDescTooLong() {
            assertThrows(IllegalArgumentException.class, () -> {
                new Task("123", "TestNameg2g", "Now let me upadate the decription to be over 50 charachter long");
            });
        }
    }

    /*
     * Null validation tests
     */

    @Nested
    class testNull {

        @Test
        void nullTestId() {
            Task task = new Task("123", "Name", "Description");
            assertNotNull(task.getId(), "Task Id must not be null");
        }

        @Test
        void nullTestName() {
            Task task = new Task("123", "Name", "Description");
            assertNotNull(task.getName(), "Name must not be null");
        }

        @Test
        void nullTestDesc() {
            Task task = new Task("123", "Name", "Description");
            assertNotNull(task.getDesc(), "Description must not be null");
        }
    }
}