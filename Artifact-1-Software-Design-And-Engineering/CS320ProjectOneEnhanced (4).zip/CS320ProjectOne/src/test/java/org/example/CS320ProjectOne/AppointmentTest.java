package org.example.CS320ProjectOne;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Calendar;

public class AppointmentTest {

    // ===== ENHANCEMENT: helper method to generate valid future dates =====
    // Improves reusability and avoids repeating date logic in every test
    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    /*
     * ===== ENHANCEMENT: nested class improves organization =====
     * Groups negative tests (null validation) together for readability
     */
    @Nested
    class testNull {

        @Test
        void testNullId() {

            // ===== ENHANCEMENT: validates constructor rejects null ID =====
            assertThrows(IllegalArgumentException.class,
                    () -> new Appointment(null, getFutureDate(), "Desc"));
        }

        @Test
        void testNullDate() {

            // ===== ENHANCEMENT: prevents appointments without valid dates =====
            assertThrows(IllegalArgumentException.class,
                    () -> new Appointment("1234", null, "Desc"));
        }

        @Test
        void testNullDesc() {

            // ===== ENHANCEMENT: ensures description cannot be null =====
            assertThrows(IllegalArgumentException.class,
                    () -> new Appointment("1234", getFutureDate(), null));
        }

        @Test
        void testSetDateNull() {

            Appointment app = new Appointment("123", getFutureDate(), "Description");

            // ===== ENHANCEMENT: setter validation prevents invalid updates =====
            assertThrows(IllegalArgumentException.class,
                    () -> app.setDate(null));
        }

        @Test
        void testSetDescNull() {

            Appointment app = new Appointment("123", getFutureDate(), "Description");

            // ===== ENHANCEMENT: ensures updates cannot introduce null values =====
            assertThrows(IllegalArgumentException.class,
                    () -> app.setDesc(null));
        }
    }

    /*
     * ===== ENHANCEMENT: boundary testing for maximum constraints =====
     * Ensures system correctly rejects oversized inputs
     */
    @Nested
    class testLength {

        @Test
        void testIdTooLong() {

            // ===== ENHANCEMENT: ID must respect max length constraint =====
            assertThrows(IllegalArgumentException.class,
                    () -> new Appointment("1234567890101", getFutureDate(), "Test"));
        }

        @Test
        void testDescTooLong() {

            // ===== ENHANCEMENT: description length validation (50 char limit) =====
            assertThrows(IllegalArgumentException.class,
                    () -> new Appointment("1234", getFutureDate(),
                            "Trying too get this over 50 charachters long. Am I over 50 yet or no? "));
        }
    }

    @Test
    void testSetDate() {

        Appointment app = new Appointment("222", getFutureDate(), "Description");
        Date newDate = getFutureDate();

        // ===== ENHANCEMENT: verifies valid update does not throw exception =====
        assertDoesNotThrow(() -> app.setDate(newDate));

        assertEquals(newDate, app.getDate());
    }

    @Test
    void testSetDesc() {

        Appointment app = new Appointment("123", getFutureDate(), "orig");

        // ===== ENHANCEMENT: ensures setter correctly updates state =====
        app.setDesc("Updated");

        assertEquals("Updated", app.getDesc());
    }

    @Test
    void testFutureDate() {

        Date fDate = getFutureDate();

        // ===== ENHANCEMENT: validates only future dates are allowed =====
        assertDoesNotThrow(() -> new Appointment("555", fDate, "my desription"));
    }
}