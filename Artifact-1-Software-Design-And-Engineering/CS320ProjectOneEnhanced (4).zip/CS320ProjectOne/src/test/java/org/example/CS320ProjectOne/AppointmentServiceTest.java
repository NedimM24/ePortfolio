package org.example.CS320ProjectOne;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;

public class AppointmentServiceTest {

    //Enhancement - Follow CamelCase and change ID to Id
    AppointmentService appointment;

    @Test
    void addAppointmentSuccess() {
        appointment = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 100);

        appointment.addAppointments("1234", futureDate, "Test desc");

        //Make sure the appointment was successfully added
        Appointment success = appointment.getAppointment("1234");

        assertTrue(success.getId().equals("1234"));
    }

    @Test
    void addContactUniqueId() {
        appointment = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 1000);

        appointment.addAppointments("555", futureDate, "Test");

        assertThrows(IllegalArgumentException.class,
                () -> appointment.addAppointments("555", futureDate, "Test"),
                "ERROR: Id must be unique");
    }

    @Test
    void deleteContact() {
        appointment = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 1000);

        appointment.addAppointments("555", futureDate, "Test");

        assertTrue(appointment.deleteAppointment("555"));
        assertFalse(appointment.deleteAppointment("555"));
    }
}