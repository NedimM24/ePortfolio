package org.example.CS320ProjectOne;

public class Task {
    private String taskId;
    private String taskName;
    private String taskDesc;

    //Enhancement - Follow CamelCase and change ID to Id
    /*
     * Constructor that validates.....
     * Id isn't over 10 chars or NULL
     * Name isn't over 20 chars or NULL
     * Description isn't over 50 chars or NULL
     */
    public Task(String id, String name, String desc) {
        if(id.length() > 10 || id == null) {
            throw new IllegalArgumentException("Id must not be longer than 10 characters or NULL!");
        }

        if(name.length() > 20 || name == null) {
            throw new IllegalArgumentException("Name must not be longer than 20 characters or NULL!");
        }

        if(desc.length() > 50 || desc == null) {
            throw new IllegalArgumentException("Description must not be longer than 50 characters or NULL!");
        }

        this.taskId = id;
        this.taskName = name;
        this.taskDesc = desc;
    }

    /*
     * Setters and getters
     * Input validation checking for length and NULL
     * No setter for Id since we want it to be unique
     */

    public String getId() { //Id
        return taskId;
    }

    public void setName(String name) { //Name
        if(name.length() > 20 || name == null) {
            throw new IllegalArgumentException("Name must not be longer than 20 characters or NULL!");
        }
        this.taskName = name;
    }

    public String getName() { //Name
        return this.taskName;
    }

    public void setDesc(String desc) { //Description
        if(desc.length() > 50 || desc == null) {
            throw new IllegalArgumentException("Description must not be longer than 50 characters or NULL!");
        }
        this.taskDesc = desc;
    }

    public String getDesc() { //Description
        return taskDesc;
    }
}