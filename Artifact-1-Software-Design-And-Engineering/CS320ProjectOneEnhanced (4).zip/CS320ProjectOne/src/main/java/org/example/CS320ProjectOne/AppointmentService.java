package org.example.CS320ProjectOne;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {

    //Enhancement - Follow CamelCase and change ID to Id
    //Will go with a ArrayList since I don't have to update appointments
    ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();

    public void addAppointments(String id, Date date, String description) {
        for(Appointment appointment: appointmentList) {
            if(id.equals(appointment.getId())){
                throw new IllegalArgumentException("Id already in use!");
            }
        }
        appointmentList.add(new Appointment(id, date, description));
    }

    public boolean deleteAppointment(String id) {
        for(Appointment appointment: appointmentList) {
            if(id.equals(appointment.getId())) {
                appointmentList.remove(appointment);
                return true;
            }
        }
        return false;
    }

    public Appointment getAppointment(String appointmentId) {
        for (Appointment appointment : appointmentList) {
            if (appointment.getId().equals(appointmentId)) {
                return appointment;
            }
        }
        throw new IllegalArgumentException("Appointment Id not found");
    }

}