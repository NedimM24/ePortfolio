package org.example.CS320ProjectOne;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    //Enhancement - Follow CamelCase and change ID to Id
    //Using HashMap to avoid continuous looping through ArrayList
    private Map<String, Task> taskMap = new HashMap<>();

    //Method to add new task
    public void addTask(String id, String name, String desc) {
        if(taskMap.containsKey(id)) {
            throw new IllegalArgumentException("Id in use");
        }

        Task addTask = new Task(id, name, desc);
        taskMap.put(id, addTask);
    }

    //Method to delete task
    public void deleteTask(String id) {
        if(!taskMap.containsKey(id)) {
            throw new IllegalArgumentException("Id not found");
        }

        taskMap.remove(id);
    }

    //Method to update name or description
    //Id cannot be changed
    //Make sure name and description aren't empty or null before updating
    public void updateTask(String id, String updateName, String updateDesc) {
        Task task = taskMap.get(id);

        if(task == null) {
            throw new IllegalArgumentException("Id not found");
        }

        if(updateName != null && !updateName.isEmpty()) {
            task.setName(updateName);
        }

        if(updateDesc != null && !updateDesc.isEmpty()) {
            task.setDesc(updateDesc);
        }
    }

    //Helper method for JUNIT5 tests
    public Task getTask(String id) {
        return taskMap.get(id);
    }
}