package org.example.CS320ProjectOne;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Calendar;

public class AppointmentTest {
	
	//Helper method for creating a future date
	private Date getFutureDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
		}
	
	/*
	 * Created a nested class to clean up code
	 * First nest will test null
	 * Test will pass if not null and fail if null
	 */
	@Nested
	class testNull{
		@Test
		void testNullID() { //Pass when not null, fail when null
			assertThrows(IllegalArgumentException.class,
					() -> new Appointment(null, getFutureDate(), "Desc"));
		}
		@Test
		void testNullDate() { //Pass when not null, fail when null
			assertThrows(IllegalArgumentException.class,
					() -> new Appointment("1234", null, "Desc"));
		}
			
		@Test
		void testNullDesc() { //Pass when not null, fail when null
			assertThrows(IllegalArgumentException.class,
					() -> new Appointment("1234", getFutureDate(), null));
		}
		
		@Test
		void testSetDateNull() {
			Appointment app = new Appointment("123", getFutureDate(), "Description");
			assertThrows(IllegalArgumentException.class,
					() -> app.setDate(null));
		}
		
		@Test 
		void testSetDescNull() {
			Appointment app = new Appointment("123", getFutureDate(), "Description");
			assertThrows(IllegalArgumentException.class,
					() -> app.setDesc(null));
		}
	}
	

	/*
	 * Nest to clean up code
	 * This nest will test ID and Description length
	 * Will fail if under character threshold and pass if above
	 */
	@Nested
	class testLength{
		@Test
		void testIDTooLong() {
	        assertThrows(IllegalArgumentException.class,
	        		() -> new Appointment("1234567890101", getFutureDate(), "Test"));
		}
		
		@Test
	    void testDescTooLong() {
			 assertThrows(IllegalArgumentException.class,
		        		() -> new Appointment("1234", getFutureDate(), "Trying too get this over 50 charachters long. Am I over 50 yet or no? "));
			}
	   
	}
	
	@Test
	void testSetDate() {
		Appointment app = new Appointment("222", getFutureDate(), "Description");
		Date newDate = getFutureDate();
		assertDoesNotThrow(()-> app.setDate(newDate));
		assertEquals(newDate, app.getDate());
	}
	
	@Test
	void testSetDesc() {
		Appointment app = new Appointment("123", getFutureDate(), "orig");
		app.setDesc("Updated");
		assertEquals("Updated", app.getDesc());
	}
	
	@Test
	void testFutureDate() {
		Date fDate = getFutureDate();
		
		assertDoesNotThrow(() -> new Appointment("555", fDate, "my desription"));
	}

}
