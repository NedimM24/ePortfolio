package org.example.CS320ProjectOne;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;


import java.util.Date;
public class AppointmentServiceTest{
	
	AppointmentService Appointment;

	@Test
	void addAppointmentSuccess() {
		Appointment = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 100);
		Appointment.addAppointments("1234", futureDate, "Test desc");
		//Make sure the appointment was successfully added
		Appointment success = Appointment.getAppointment("1234");
		assertTrue(success.getID().equals("1234"));
	}
	
	
	
	
	@Test
    void addContactUniqueID() {
        Appointment = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000);
        Appointment.addAppointments("555", futureDate, "Test");
        assertThrows(IllegalArgumentException.class,
            () -> Appointment.addAppointments("555", futureDate, "Test"),
            "ERROR: ID must be unique");
    }
	
	@Test
    void deleteContact() {
        Appointment = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000);
        Appointment.addAppointments("555", futureDate, "Test");
        assertTrue(Appointment.deleteAppointment("545"));
        assertFalse(Appointment.deleteAppointment("545"));

	}
}
