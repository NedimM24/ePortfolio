package org.example.CS320ProjectOne;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;


class TaskTest {

	//Testing the Task class and constructor using assertTrue
    @Test
    void testTaskClass() {
        Task task = new Task("123", "Test", "Testing the class");
        assertTrue(task.getID().equals("123"));
        assertTrue(task.getName().equals("Test"));
        assertTrue(task.getDesc().equals("Testing the class"));
    }
    
    /*
     * Created a nested tests to clean up my code
     * Inside the nest we will test length of ID, Name, and Description
     * Tests are working as expected
     * Use asserThrows to verify my functions are throwing exceptions
     */
    @Nested
    class testLength{
    
    @Test
    void testIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("6546446556456646566", "TestName", "Under fifty chars");
        });
    }
    
    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "TestNameLongerThan20Char", "Under fifty chars");
        });
    }
    
    @Test
    void testDescTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "TestNameg2g", "Now let me upadate the decription to be over 50 charachter long");
        });
    }
    
    /*
     * Created a nested tests to clean up my code
     * Inside the nest we will test to make sure that ID, Name, and Description isn't null
     * Tests are working as expected
     * Use asserThrows to verify my functions are throwing exceptions
     */
    
    @Nested
    class testNull{
    	 @Test
         void nullTestID() {
             Task contact = new Task("123", "Name", "Description");
             assertNotNull(contact.getID(), "Task ID must not be null");
         }
    }
    @Test
    void nullTestName() {
        Task contact = new Task("123", "Name", "Description");
        assertNotNull(contact.getID(), "Name must not be null");
    }
}
    @Test
    void nullTestDesc() {
        Task contact = new Task("123", "Name", "Description");
        assertNotNull(contact.getID(), "Description must not be null");
    }
}
