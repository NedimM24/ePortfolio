package org.example.CS320ProjectOne;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	
	private TaskService taskService = new TaskService();
	//Testing add task
	@Test
	void addTaskTest() {
		taskService.addTask("555", "taskName", "Just a description");
		Task task = taskService.getTask("555");
		
		assertEquals("taskName", task.getName());
		assertEquals("Just a description", task.getDesc());
	}

	//Testing delete task
	@Test
	void deleteTaskTest() {
		taskService.addTask("555", "taskName", "Just a description");
		assertNull(taskService.getTask(null));
	}
	
	//Testing update task
	@Test
	void updateTaskTest() {
		taskService.addTask("555", "taskName", "Just a description");
		taskService.updateTask("555", "new", "New description");
		
		Task task = taskService.getTask("555");
		assertEquals("new", task.getName());
		assertEquals("New description", task.getDesc());
	}

}
