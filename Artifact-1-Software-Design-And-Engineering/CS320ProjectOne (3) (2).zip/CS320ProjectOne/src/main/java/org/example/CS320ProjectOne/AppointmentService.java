package org.example.CS320ProjectOne;

import java.util.ArrayList;
import java.util.Date;


public class AppointmentService {
	
	//Will go with a ArrayList since I don't have to update appointments
	ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	public void addAppointments(String ID, Date date, String description) {
		for(Appointment appointment: appointmentList) {
			if(ID.equals(appointment.getID())){
				throw new IllegalArgumentException("ID already in use!");
			}
		}
		appointmentList.add(new Appointment(ID, date, description));
	}
	
	public boolean deleteAppointment(String ID) {
		for(Appointment appointment: appointmentList) {
			if(ID.equals(appointment.getID())) {
				appointmentList.remove(appointment);
				return true;
			}
		}
		return false;
	}
	
	public Appointment getAppointment(String appointmentID) {
        for (Appointment appointment : appointmentList) {
            if (appointment.getID().equals(appointmentID)) {
                return appointment;
            }
        }
        throw new IllegalArgumentException("Appointment ID not found");
    }

}

