package org.example.CS320ProjectOne;

import java.util.Date;

public class Appointment {
	//Private variables
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDesc;
	
	/*
	 * Constructor 
	 * Checks for null
	 * checks for length
	 * makes sure that date isn't in the past
	 */
	public Appointment(String ID, Date date, String desc) {
		if(ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("ID cannot be null or longer than 10 charachters!");
		}
		if(date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Date cannot be null or be a past date!");
		}
		if(desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Description cannot be null or longer than 50 charachters!");
		}
		this.appointmentID = ID;
		this.appointmentDate = date;
		this.appointmentDesc = desc;
	}

	/*
	 * Getters and setters
	 * Also contain validation and will throw IllegalArgumentExceptions
	 * No setter for ID since it shouldn't be updatable
	 */
	
	public String getID() {
		return this.appointmentID;
	}
	
	public void setDate(Date date) {
		if(date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Date cannot be null or be a past date!");
	}
		this.appointmentDate = date;
	}
	public Date getDate() {
		return this.appointmentDate;
	}
	
	public void setDesc(String desc) {
		if(desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Description cannot be null or longer than 50 charachters!");
		}
		this.appointmentDesc = desc;
	}
	public String getDesc() {
		return this.appointmentDesc;
	}

}
