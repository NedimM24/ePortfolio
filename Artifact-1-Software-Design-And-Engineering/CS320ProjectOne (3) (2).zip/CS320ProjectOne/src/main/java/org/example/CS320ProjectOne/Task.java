package org.example.CS320ProjectOne;

public class Task {
	private String taskID;
	private String taskName;
	private String taskDesc;
	
	/*
	 * Constructor that validates.....
	 * ID isn't over 10 chars or NULL
	 * Name isn't over 20 chars or NULL
	 * Description isn't over 50 chars or NULL
	 */
		public Task(String ID, String name, String desc) {
		if(ID.length() > 10 || ID == null) {
			throw new IllegalArgumentException("ID must not be longer than 10 characters or NULL!");
		}
		
		if(name.length() > 20 || name == null) {
			throw new IllegalArgumentException("Name must not be longer than 20 characters or NULL!");
		}
		
		if(desc.length() > 50 || desc == null) {
			throw new IllegalArgumentException("Description must not be longer than 50 characters or NULL!");
		}
		
		this.taskID = ID;
		this.taskName = name;
		this.taskDesc = desc;
	}
		
		/*
		 * Setters and getters
		 * Input validation checking for length and NULL
		 * No setter for ID since we want it to be unique
		 */
		
		public String getID() { //ID
			return taskID;
		}
		
		public void setName(String name) { //Name
			if(name.length() > 20 || name == null) {
				throw new IllegalArgumentException("Name must not be longer than 20 characters or NULL!");
		}
			this.taskName = name;
		}
		public String getName() { //Name
			return this.taskName;
		}
		
		public void setDesc(String desc) { //Description
			if(desc.length() > 50 || desc == null) {
				throw new IllegalArgumentException("Description must not be longer than 50 characters or NULL!");
			}
			this.taskDesc = desc;
		}
		public String getDesc() { //Description
			return taskDesc;
		}
}