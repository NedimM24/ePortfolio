package org.example.CS320ProjectOne;

import java.util.HashMap;
import java.util.Map;


public class TaskService {
	
	//Using HashMap to avoid continuous looping through ArrayList
	private Map<String, Task> taskMap = new HashMap<>();
	
	//Method to add new task
	public void addTask(String ID, String name, String desc) {
		if(taskMap.containsKey(ID)) {
			throw new IllegalArgumentException("ID in use");
		}
		Task addTask = new Task(ID, name, desc);
		taskMap.put(ID, addTask);
	}
	
	//Method to delete task
	public void deleteTask(String ID) {
		if(!taskMap.containsKey(ID)) {
			throw new IllegalArgumentException("ID not found");
		}
		taskMap.remove(ID);
	}
	//Method to update name or description
	//ID cannot be changed
	//Make sure name and description aren't empty or null before updating
	public void updateTask(String ID, String updateName, String updateDesc) {
		Task task = taskMap.get(ID);
		if(task == null) {
			throw new IllegalArgumentException("ID not found");
		}
		if(updateName != null && !updateName.isEmpty()) {
			task.setName(updateName);
		}
		if(updateDesc != null && !updateDesc.isEmpty()) {
			task.setDesc(updateDesc);
		}
	}
	
	//Helper method for JUNIT5 tests
	public Task getTask(String ID) {
		return taskMap.get(ID);
	}
}
