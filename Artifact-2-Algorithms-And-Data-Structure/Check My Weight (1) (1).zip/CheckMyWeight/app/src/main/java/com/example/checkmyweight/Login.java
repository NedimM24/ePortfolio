package com.example.checkmyweight;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    EditText username, password;
    Button loginButton, signupButton;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database
        db = new Database(this);

        // Initialize UI elements
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signupButton = findViewById(R.id.signupButton);

        // LOGIN BUTTON
        loginButton.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(Login.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.checkUser(user, pass)) {
                Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                // Go to MainActivity
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);

                // Close Login so user can't go back
                finish();
            } else {
                Toast.makeText(Login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // SIGNUP BUTTON
        signupButton.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(Login.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if user already exists
            if (db.checkUser(user, pass)) { // we use checkUser because your Database currently does not have userExists()
                Toast.makeText(Login.this, "User already exists!", Toast.LENGTH_SHORT).show();
            } else {
                boolean inserted = db.insertUser(user, pass);
                if (inserted) {
                    Toast.makeText(Login.this, "Account Created!", Toast.LENGTH_SHORT).show();

                    // Go to MainActivity after signup
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);

                    finish();
                } else {
                    Toast.makeText(Login.this, "Error creating account", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}