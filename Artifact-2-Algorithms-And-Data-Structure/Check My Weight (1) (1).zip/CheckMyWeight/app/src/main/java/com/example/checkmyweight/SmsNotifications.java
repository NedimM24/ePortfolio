package com.example.checkmyweight;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotifications extends AppCompatActivity {

    private TextView statusText;
    private Button permissionButton, backButton;

    private final int SMS_PERMISSION_CODE = 1; // request code

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        // Initialize views
        statusText = findViewById(R.id.statusText);
        permissionButton = findViewById(R.id.permissionButton);
        backButton = findViewById(R.id.backButton);

        // SMS permission button
        permissionButton.setOnClickListener(v -> requestSmsPermission());

        // Back button functionality: return to MainActivity
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(SmsNotifications.this, MainActivity.class);
            startActivity(intent);
            finish(); // close SMS page
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission already granted
            statusText.setText("SMS permission already granted");
            sendTestSms(); // optional test message or trigger alert
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                statusText.setText("SMS permission granted");
                sendTestSms(); // trigger alert SMS
            } else {
                // Permission denied
                statusText.setText("SMS permission denied. App will still function without SMS notifications.");
                Toast.makeText(this, "You denied SMS permission. Notifications via SMS won't work.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Example function to send an SMS
    private void sendTestSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = ""; // replace with actual number or user input
            String message = "This is a test SMS alert from your weight tracker app!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Test SMS sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}