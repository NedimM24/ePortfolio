package com.example.checkmyweight;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;

public class MainActivity extends AppCompatActivity {

    Database db;
    LinearLayout gridContainer;
    Button addWeightButton, setGoalButton, smsButton;
    TextView currentWeightText, goalWeightText, poundsAwayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new Database(this);

        // UI references
        gridContainer = findViewById(R.id.gridContainer);
        addWeightButton = findViewById(R.id.addWeightButton);
        setGoalButton = findViewById(R.id.setGoalButton);
        smsButton = findViewById(R.id.smsButton);

        currentWeightText = findViewById(R.id.currentWeightText);
        goalWeightText = findViewById(R.id.goalWeightText);
        poundsAwayText = findViewById(R.id.poundsAwayText);

        // Load the weights into the grid
        loadWeights();

        // Add weight button listener
        addWeightButton.setOnClickListener(v -> showAddWeightDialog());

        // Set goal weight button listener
        setGoalButton.setOnClickListener(v -> showSetGoalDialog());

        // SMS button listener
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SmsNotifications.class);
            startActivity(intent);
        });
    }

    // ===================== LOAD WEIGHTS =====================
    private void loadWeights() {
        gridContainer.removeAllViews();
        Cursor cursor = db.getAllWeights();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            double weight = cursor.getDouble(2);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(10, 10, 10, 10);

            // Date
            TextView dateView = new TextView(this);
            dateView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 2));
            dateView.setText(date);

            // Weight
            TextView weightView = new TextView(this);
            weightView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 2));
            weightView.setText(String.valueOf(weight));

            // Edit Button
            Button editBtn = new Button(this);
            editBtn.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 2));
            editBtn.setText("Edit");
            editBtn.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.oliveGreen)));
            editBtn.setTextColor(getResources().getColor(android.R.color.white));
            editBtn.setOnClickListener(v -> showUpdateDialog(id));

            // Delete Button
            Button deleteBtn = new Button(this);
            deleteBtn.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            deleteBtn.setText("-");
            deleteBtn.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.oliveGreen)));
            deleteBtn.setTextColor(getResources().getColor(android.R.color.white));
            deleteBtn.setOnClickListener(v -> {
                db.deleteWeight(id);
                loadWeights();
            });

            row.addView(dateView);
            row.addView(weightView);
            row.addView(editBtn);
            row.addView(deleteBtn);

            gridContainer.addView(row);
        }

        cursor.close();
    }

    // ===================== ADD WEIGHT =====================
    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Today's Weight");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText dateInput = new EditText(this);
        dateInput.setHint("Date (MM/DD/YYYY)");

        EditText weightInput = new EditText(this);
        weightInput.setHint("Weight");
        weightInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        layout.addView(dateInput);
        layout.addView(weightInput);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String date = dateInput.getText().toString();
            double weight = Double.parseDouble(weightInput.getText().toString());
            db.addWeight(date, weight);

            // Update Today's Weight
            currentWeightText.setText(String.valueOf(weight));

            // Update Pounds Away
            updatePoundsAway(weight);

            loadWeights();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ===================== UPDATE WEIGHT =====================
    private void showUpdateDialog(int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Weight");

        EditText weightInput = new EditText(this);
        weightInput.setHint("New Weight");
        weightInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        builder.setView(weightInput);

        builder.setPositiveButton("Update", (dialog, which) -> {
            double newWeight = Double.parseDouble(weightInput.getText().toString());
            db.updateWeight(id, newWeight);

            // Update Today's Weight if it's the most recent
            Cursor cursor = db.getAllWeights();
            if (cursor.moveToLast()) {
                double latestWeight = cursor.getDouble(2);
                currentWeightText.setText(String.valueOf(latestWeight));
                updatePoundsAway(latestWeight);
            }
            cursor.close();

            loadWeights();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ===================== SET GOAL =====================
    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        EditText goalInput = new EditText(this);
        goalInput.setHint("Goal Weight");
        goalInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        builder.setView(goalInput);

        builder.setPositiveButton("Set", (dialog, which) -> {
            double goal = Double.parseDouble(goalInput.getText().toString());
            goalWeightText.setText(String.valueOf(goal));

            // Update Pounds Away
            double currentWeight = Double.parseDouble(currentWeightText.getText().toString());
            updatePoundsAway(currentWeight);
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ===================== UPDATE POUNDS AWAY =====================
    private void updatePoundsAway(double currentWeight) {
        double goal = Double.parseDouble(goalWeightText.getText().toString());
        double difference = Math.abs(goal - currentWeight);
        poundsAwayText.setText(String.format("%.1f lbs away from goal", difference));
    }
}